import 'package:flutter/material.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:intl/intl.dart'; // To format the date

void main() => runApp(const MyApp());

/// User model with birth date
class User {
  final String name;
  final int age;
  final String healthCard;
  final String sex;
  final String birthDate;
  final String password;

  User({
    required this.name,
    required this.age,
    required this.healthCard,
    required this.sex,
    required this.birthDate,
    required this.password,
  });
}

/// In-memory user manager
class UserManager {
  static User? registeredUser;
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.teal,
        useMaterial3: true,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.teal,
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      themeMode: ThemeMode.system,
      home: const LoginPage(),
    );
  }
}

/// Login Page
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _healthCardController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _login(BuildContext context) {
    final user = UserManager.registeredUser;
    if (user != null &&
        _healthCardController.text == user.healthCard &&
        _passwordController.text == user.password) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid NHI number or password')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.teal, Colors.blueAccent],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.medical_services, size: 100, color: Colors.white),
                  const SizedBox(height: 20),
                  Text(
                    'Welcome Back',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Sign in to continue',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white60),
                  ),
                  const SizedBox(height: 24),
                  _buildInputField(_healthCardController, 'NHI Number', Icons.credit_card),
                  const SizedBox(height: 16),
                  _buildInputField(_passwordController, 'Password', Icons.lock),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () => _login(context),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      shadowColor: Colors.black26,
                      elevation: 5,
                      backgroundColor: Colors.teal,
                    ),
                    child: const Text('Sign In', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: const Text('Forgot Password?', style: TextStyle(color: Colors.white)),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SignupPage()),
                    ),
                    child: const Text('Don\'t have an account? Sign Up', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField(TextEditingController controller, String labelText, IconData icon) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: labelText,
        labelStyle: const TextStyle(color: Colors.white),
        prefixIcon: Icon(icon, color: Colors.white),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        filled: true,
        fillColor: Colors.white.withOpacity(0.1),
        focusColor: Colors.white,
      ),
      obscureText: labelText == 'Password',
      readOnly: false,
    );
  }
}

/// Signup Page
class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  _SignupPageState createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _sexController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _healthCardController = TextEditingController();
  final TextEditingController _birthDateController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  Future<void> _pickBirthDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      final formatted = DateFormat('yyyy-MM-dd').format(picked);
      _birthDateController.text = formatted;
    }
  }

  void _signup(BuildContext context) {
    final user = User(
      name: _nameController.text.trim(),
      sex: _sexController.text.trim(),
      age: int.tryParse(_ageController.text.trim()) ?? 0,
      healthCard: _healthCardController.text.trim(),
      birthDate: _birthDateController.text.trim(),
      password: _passwordController.text.trim(),
    );
    UserManager.registeredUser = user;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign Up'), backgroundColor: Colors.teal),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            _buildField(_nameController, 'Name', Icons.person),
            const SizedBox(height: 16),
            _buildField(_sexController, 'Sex', Icons.transgender),
            const SizedBox(height: 16),
            _buildField(_ageController, 'Age', Icons.cake),
            const SizedBox(height: 16),
            _buildField(_healthCardController, 'NHI Number', Icons.credit_card),
            const SizedBox(height: 16),
            TextField(
              controller: _birthDateController,
              readOnly: true,
              decoration: InputDecoration(
                labelText: 'Birth Date',
                prefixIcon: const Icon(Icons.calendar_today),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
              ),
              onTap: () => _pickBirthDate(context),
            ),
            const SizedBox(height: 16),
            _buildField(_passwordController, 'Password', Icons.lock, obscure: true),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => _signup(context),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                backgroundColor: Colors.teal,
              ),
              child: const Text('Sign Up', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField(TextEditingController controller, String label, IconData icon, {bool obscure = false}) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }
}

/// SaveImageScreen, ViewImageScreen, HomeScreen, GalleryScreen, FullImageScreen remain largely unchanged,
/// but HomeScreen now pulls data from UserManager and adds a logout button.

class SaveImageScreen extends StatelessWidget {
  const SaveImageScreen({super.key});

  Future<void> _takePhoto(BuildContext context) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      final image = File(pickedFile.path);
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ViewImageScreen(image: image),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No photo taken')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text('Take Photo')), body: Center(
      child: ElevatedButton(
        onPressed: () => _takePhoto(context),
        style: ElevatedButton.styleFrom(
          minimumSize: const Size.fromHeight(48),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          backgroundColor: Colors.teal,
        ),
        child: const Text('Take Photo', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    ));
  }
}

class ViewImageScreen extends StatelessWidget {
  final File image;
  const ViewImageScreen({super.key, required this.image});

  Future<void> _saveImage(BuildContext context) async {
    final appDir = await getApplicationDocumentsDirectory();
    final dateFormat = DateFormat('yyyy-MM-dd_HH-mm-ss');
    final dateString = dateFormat.format(DateTime.now());
    final fileName = 'photo_$dateString.jpg';
    await image.copy('${appDir.path}/$fileName');
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  void _retakePhoto(BuildContext context) {
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('View Photo')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.file(image, height: 300, fit: BoxFit.cover),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () => _saveImage(context),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(120, 48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    backgroundColor: Colors.teal,
                  ),
                  child: const Text('Save', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 20),
                ElevatedButton(
                  onPressed: () => _retakePhoto(context),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(120, 48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    backgroundColor: Colors.red,
                  ),
                  child: const Text('Delete', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = UserManager.registeredUser;
    return Scaffold(
      appBar: AppBar(title: const Text('Medical Profile'), backgroundColor: Colors.teal),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: ListView(
          children: [
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 4,
              shadowColor: Colors.black.withOpacity(0.1),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildInfoRow('Name', user?.name ?? ''),
                    const Divider(),
                    _buildInfoRow('NHI Number', user?.healthCard ?? ''),
                    const Divider(),
                    _buildInfoRow('Gender', user?.sex ?? ''),
                    const Divider(),
                    _buildInfoRow('Age', user?.age.toString() ?? ''),
                    const Divider(),
                    _buildInfoRow('Birth Date', user?.birthDate ?? ''),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            _buildRoundedButton(context, Icons.camera_alt_outlined, 'Capture Image', const SaveImageScreen()),
            const SizedBox(height: 12),
            _buildRoundedButton(context, Icons.photo_library_outlined, 'Open Gallery', const GalleryScreen()),
            const SizedBox(height: 12),
            TextButton.icon(
              onPressed: () => Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              ),
              icon: const Icon(Icons.logout, color: Colors.teal),
              label: const Text('Logout', style: TextStyle(color: Colors.teal)),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: Colors.grey)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildRoundedButton(BuildContext context, IconData icon, String label, Widget screen) {
    return ElevatedButton.icon(
      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => screen)),
      icon: Icon(icon, color: Colors.white),
      label: Text(label, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
      style: ElevatedButton.styleFrom(
        minimumSize: const Size.fromHeight(48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        shadowColor: Colors.black26,
        elevation: 4,
        backgroundColor: Colors.teal,
      ),
    );
  }
}

class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

/// Updated GalleryScreen and FullImageScreen with deletion-aware navigation

class _GalleryScreenState extends State<GalleryScreen> {
  late List<FileSystemEntity> _images = [];

  @override
  void initState() {
    super.initState();
    _loadImages();
  }

  Future<void> _loadImages() async {
    final dir = await getApplicationDocumentsDirectory();
    final files = dir
        .listSync()
        .where((e) => e.path.endsWith('.jpg') || e.path.endsWith('.png'))
        .toList();
    setState(() => _images = files);
  }

  Future<void> _deleteImage(FileSystemEntity file) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Deletion'),
        content: const Text('Are you sure you want to delete this image?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              await file.delete();
              _loadImages();
              Navigator.of(context).pop();
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Saved Images')),
      body: _images.isEmpty
          ? const Center(child: Text('No images found'))
          : GridView.builder(
        padding: const EdgeInsets.all(8),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemCount: _images.length,
        itemBuilder: (context, index) {
          final file = File(_images[index].path);
          return Stack(
            children: [
              Positioned.fill(
                child: GestureDetector(
                  onTap: () async {
                    // Navigate to full-screen view and await deletion result
                    final deleted = await Navigator.push<bool>(
                      context,
                      MaterialPageRoute(
                        builder: (_) => FullImageScreen(image: file),
                      ),
                    );
                    if (deleted == true) {
                      _loadImages(); // Refresh gallery after deletion
                    }
                  },
                  child: Image.file(file, fit: BoxFit.cover),
                ),
              ),
              Positioned(
                top: 4,
                right: 4,
                child: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _deleteImage(_images[index]),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// FullImageScreen that returns a bool indicating if the image was deleted
class FullImageScreen extends StatelessWidget {
  final File image;
  const FullImageScreen({super.key, required this.image});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Full Image'), backgroundColor: Colors.teal),
      body: Center(child: Image.file(image)),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context, false); // No deletion
              },
              icon: const Icon(Icons.arrow_back),
              label: const Text('Back'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(120, 48),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                backgroundColor: Colors.teal,
              ),
            ),
            ElevatedButton.icon(
              onPressed: () async {
                await image.delete();
                Navigator.pop(context, true); // Notify deletion
              },
              icon: const Icon(Icons.delete),
              label: const Text('Delete'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(120, 48),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                backgroundColor: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
